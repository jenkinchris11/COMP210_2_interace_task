# Intro To Vive Development
Unity project for the Intro to VR Development for the HTC Vive tutorial provided on academyofvr.com.
Tutorial originally written using Unity 5.5.1f1 and SteamVR plugin for Unity – v1.1.1.
